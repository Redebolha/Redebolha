/* Rede Bolha — comportamento comum a todas as páginas.
   Tema claro/escuro, busca e menu do celular. O carrossel é só da home
   e mora no próprio index.html. */
(function () {
  'use strict';

  var raiz = document.documentElement;

  /* ---------- tema claro / escuro ---------- */
  try {
    var salvo = localStorage.getItem('rb-tema');
    if (salvo) raiz.setAttribute('data-theme', salvo);
  } catch (e) {}

  var btTema = document.getElementById('btTema');
  if (btTema) {
    btTema.addEventListener('click', function () {
      var atual = raiz.getAttribute('data-theme');
      if (!atual) {
        atual = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      }
      var novo = atual === 'dark' ? 'light' : 'dark';
      raiz.setAttribute('data-theme', novo);
      try { localStorage.setItem('rb-tema', novo); } catch (e) {}
    });
  }

  /* ---------- busca ---------- */
  var busca = document.getElementById('busca');
  var btBusca = document.getElementById('btBusca');
  if (busca && btBusca) {
    btBusca.addEventListener('click', function () {
      busca.classList.toggle('aberta');
      if (busca.classList.contains('aberta')) document.getElementById('q').focus();
    });
  }

  /* ---------- menu no celular ---------- */
  var btMenu = document.getElementById('btMenu');
  var gaveta = document.getElementById('gaveta');
  if (btMenu && gaveta) {
    btMenu.addEventListener('click', function () {
      var aberta = gaveta.classList.toggle('aberta');
      btMenu.setAttribute('aria-expanded', aberta ? 'true' : 'false');
    });
  }

  /* ---------- revelação ao rolar ---------- */
  var alvos = [].slice.call(document.querySelectorAll('.revela'));
  if (!alvos.length) return;
  var pausado = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (pausado || !('IntersectionObserver' in window)) {
    alvos.forEach(function (el) { el.classList.add('dentro'); });
    return;
  }
  var obs = new IntersectionObserver(function (itens) {
    itens.forEach(function (it) {
      if (it.isIntersecting) { it.target.classList.add('dentro'); obs.unobserve(it.target); }
    });
  }, { threshold: .12, rootMargin: '0px 0px -6% 0px' });
  alvos.forEach(function (el) { obs.observe(el); });
  // rede de segurança: se algo impedir o observador, o conteúdo aparece assim mesmo
  setTimeout(function () { alvos.forEach(function (el) { el.classList.add('dentro'); }); }, 2500);
})();
